#/bin/sh
./dip_switch digital.config DSW4 $1