#/bin/sh
./dip_switch digital.config DSW3 $1