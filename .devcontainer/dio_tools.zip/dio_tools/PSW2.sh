#/bin/sh
./push_button digital.config PSW2
