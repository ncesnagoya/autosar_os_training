#/bin/sh
./digital_state digital.config