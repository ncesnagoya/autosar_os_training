#/bin/sh
./dip_switch digital.config DSW1 $1