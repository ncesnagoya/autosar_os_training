#/bin/sh
./dip_switch digital.config DSW2 $1